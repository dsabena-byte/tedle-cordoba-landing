document.getElementById('root').innerHTML = `
  <h1>Paneles Solares Tier One en Córdoba</h1>
  <p>Stock local · Retiro en 2h · Precios mayoristas para instaladores</p>
  <a href='https://wa.me/5493510000000?text=Quiero%20lista%20mayorista'>WhatsApp Ahora</a>
`;